package validation.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import validation.service.AuthenticationServiceImpl;

@RestController
public class UserController {
	
	@Autowired
	AuthenticationServiceImpl service;
	
	@GetMapping("/check")
	public String auth(@RequestParam String username , @RequestParam String password) {
		
		return service.isValid(username, password);
	}
	

	
	
	
	

}
