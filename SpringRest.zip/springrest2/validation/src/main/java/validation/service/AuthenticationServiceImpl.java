package validation.service;

import org.springframework.stereotype.Service;

import validation.model.UserDetails;

@Service
public class AuthenticationServiceImpl implements Authentication {
	
	UserDetails user = new UserDetails();

	@Override
	public String isValid(String username, String password) {
		if(username.equals(user.getUsername())&& password.equals(user.getPassword())) {
			return "Valid User "+username;
		}
		else {

		return "Invalid user "+username;
		}
	}

}
