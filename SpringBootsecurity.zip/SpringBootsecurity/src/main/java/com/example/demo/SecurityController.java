package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecurityController {
	@RequestMapping(path="/hello")
	public String hello() {
		return "Hello World";
	}
	@RequestMapping(path="/hii")
	public String hi() {
		return " World";
	}
	@RequestMapping(path="/user")
	public String user() {
		return " user";
	}
	@RequestMapping(path="/admin")
	public String admin() {
		return " admin";
	}
}
