package com.firstspring;

public class HelloWorld {
	public void method() {
		System.out.println("Hello World");
		
	}

}
