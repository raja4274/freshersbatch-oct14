package springcore10;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		AbstractApplicationContext  context = new ClassPathXmlApplicationContext("beans.xml");
		ContextWare appcontext= (ContextWare)context.getBean("context");
		ApplicationContext appCon =appcontext.getContext();
		Class a= (Class)appCon.getBean("pro");
		a.doTask();	
	}
}