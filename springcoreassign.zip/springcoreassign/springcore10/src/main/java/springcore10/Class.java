package springcore10;

public class Class {
	
	public void doTask(){
		System.out.println("Do something");
	}
}
