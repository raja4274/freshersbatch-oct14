package springcore3;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		BankAccount account = (BankAccount) context.getBean("account");
		BankAccountRepositoryImpl accountImpl = (BankAccountRepositoryImpl) context.getBean("emp1");
		BankAccountServiceImpl services = (BankAccountServiceImpl) context.getBean("emp2");
		System.out.println(account);
		System.out.println(accountImpl);
		System.out.println(services);
		
	}

}
