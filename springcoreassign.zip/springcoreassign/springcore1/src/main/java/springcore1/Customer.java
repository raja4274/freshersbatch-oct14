package springcore1;

public class Customer {
	int customerid;
	String customername;
	int customernum;
	Address address;
	
	public Customer() {
		
	}
	public Customer(Address address) {
		this.address=address;
	}
	public Customer(int cid, String cname, int cnum, Address address) {
		super();
		this.customerid = cid;
		this.customername = cname;
		this.customernum = cnum;
		this.address = address;
	}
	public int getCid() {
		return customerid;
	}
	public void setCid(int cid) {
		this.customerid = cid;
	}
	public String getCname() {
		return customername;
	}
	public void setCname(String cname) {
		this.customername = cname;
	}
	public int getCnum() {
		return customernum;
	}
	public void setCnum(int cnum) {
		this.customernum = cnum;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customername=" + customername + ", customernum=" + customernum + ", address=" + address + "]";
	}
	public void myInit() {
		System.out.println("--------object initialized--------");
	}
	public void myDestroy() {
		System.out.println("-------object destroyed------");
	}

}