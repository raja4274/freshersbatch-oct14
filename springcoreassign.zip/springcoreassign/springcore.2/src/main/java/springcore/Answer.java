package springcore;

import java.util.*;

public class Answer {
	List<String> answerList;
	Set<String> answerSet;
	Map<Integer, String> answerMap;
}
