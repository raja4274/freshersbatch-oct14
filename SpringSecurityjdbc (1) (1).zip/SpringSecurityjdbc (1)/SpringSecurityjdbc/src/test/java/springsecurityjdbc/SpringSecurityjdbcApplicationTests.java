package springsecurityjdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityjdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
