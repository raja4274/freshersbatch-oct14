INSERT INTO users(username,password,enabled)
values('raja',
'pass',true);

INSERT INTO users(username,password,enabled)
values('anil',
'raja',true);

INSERT INTO authorities(username,authority)
values('raja','ROLE_USER');

INSERT INTO authorities(username,authority)
values('anil','ROLE_ADMIN');