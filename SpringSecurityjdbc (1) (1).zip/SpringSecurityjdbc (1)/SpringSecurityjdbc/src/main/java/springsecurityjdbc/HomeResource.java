package springsecurityjdbc;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeResource {
	@GetMapping(path="/hello")
	public String hello() {
		return "Hello World";
	}
	@GetMapping(path="/hii")
	public String hi() {
		return " World";
	}
	@GetMapping(path="/user")
	public String user() {
		return " user";
	}
	@GetMapping(path="/admin")
	public String admin() {
		return " admin";
	}
}
